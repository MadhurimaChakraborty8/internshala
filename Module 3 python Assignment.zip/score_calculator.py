#Function for batting

def batscore(d): 

    name=d.get('name')
    runs=d.get('runs')
    balls=d.get('balls')
    score=runs//2
    four=d.get('4')
    six=d.get('6')
    strike_rate=runs/balls

    score=runs//2
    if (score>=50):
        score=score+5
    if (score>=100):
       score=score+10

    strike_rate=runs/balls
    if (strike_rate>=80 and strike_rate<=100):
        score=score+2
    if (strike_rate>100):
        score=score+4
    if (four>0):
        score=score+(four*1)
    if (six>0):
        score=score+(six*2)
    return score
    return {'name':name,'batscore':score}


#Function for bowling

def bowlscore(d):

     name=d.get('name')
     wkt=d.get('wkts')
     balls=d.get('overs')
     runs=d.get('runs')
     score=wkt*10
     economy_rate=runs/balls

     score=wkt*10
     if (wkt>=3):
         score=score+5
     if (wkt>=5):
         score=score+10
         
     economy_rate=runs/balls
     if (economy_rate<=2):
         score=score+10
     if (economy_rate>2 and economy_rate<=3.5):
         score=score+7
     if (economy_rate>3.5 and economy_rate<=4.5):
         score=score+4
     return score
     return{'name':name,'bowlscore':score}


